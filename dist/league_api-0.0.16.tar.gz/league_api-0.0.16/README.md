# League of data ingestion API

This is my package to abstract league of legends API calls

It's for simple use.